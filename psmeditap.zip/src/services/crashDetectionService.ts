import { getNearestHospital, Hospital } from './hospitalService';
import { supabase } from '../lib/supabase';

export interface CrashEvent {
  timestamp: number;
  location: {
    lat: number;
    lng: number;
  };
  hospital: Hospital | null;
}

class CrashDetectionService {
  private isMonitoring: boolean = false;
  private isTriggering: boolean = false;
  private lastAcceleration: number = 0;
  private stasisStartTime: number | null = null;
  private onCrashDetected: (event: CrashEvent) => void = () => {};
  
  // Thresholds
  private readonly CRASH_THRESHOLD = 35; // ~3.5G in m/s²
  private readonly STASIS_THRESHOLD = 2; // ~0.2G (near zero movement)
  private readonly STASIS_DURATION = 3000; // 3 seconds of stasis after impact

  setCrashCallback(callback: (event: CrashEvent) => void) {
    this.onCrashDetected = callback;
  }

  async requestPermissions(): Promise<{ granted: boolean; error?: string }> {
    // Check if we are in an iframe
    const isInIframe = window.self !== window.top;
    
    if (typeof DeviceMotionEvent === 'undefined') {
      return { 
        granted: false, 
        error: 'DeviceMotion is not supported by this browser or device.' 
      };
    }

    // iOS 13+ requires explicit permission
    if (typeof (DeviceMotionEvent as any).requestPermission === 'function') {
      try {
        const permission = await (DeviceMotionEvent as any).requestPermission();
        if (permission === 'granted') return { granted: true };
        return { granted: false, error: 'Permission denied by user.' };
      } catch (error) {
        console.error('Error requesting motion permission:', error);
        return { 
          granted: false, 
          error: isInIframe 
            ? 'Permission request failed. This often happens in iframes. Try opening the app in a new tab.' 
            : 'Permission request failed.' 
        };
      }
    }

    // For other browsers, we check if the event actually fires
    // Some browsers (like Chrome on Android) might block it in iframes without proper 'allow' attribute
    return new Promise((resolve) => {
      let receivedData = false;
      const testHandler = (e: DeviceMotionEvent) => {
        if (e.accelerationIncludingGravity) {
          receivedData = true;
          window.removeEventListener('devicemotion', testHandler);
          resolve({ granted: true });
        }
      };

      window.addEventListener('devicemotion', testHandler);

      // Timeout if no data received
      setTimeout(() => {
        window.removeEventListener('devicemotion', testHandler);
        if (!receivedData) {
          resolve({ 
            granted: false, 
            error: isInIframe 
              ? 'No sensor data received. Sensors are likely blocked in the preview. Please open the app in a new tab to use this feature.' 
              : 'No sensor data received. Your device may not have the required sensors.' 
          });
        }
      }, 500);
    });
  }

  start() {
    if (this.isMonitoring) return;
    this.isMonitoring = true;
    this.isTriggering = false;
    window.addEventListener('devicemotion', this.handleMotion);
    console.log('Crash detection started');
  }

  stop() {
    this.isMonitoring = false;
    window.removeEventListener('devicemotion', this.handleMotion);
    this.stasisStartTime = null;
    console.log('Crash detection stopped');
  }

  private handleMotion = (event: DeviceMotionEvent) => {
    if (this.isTriggering) return;
    const acc = event.accelerationIncludingGravity;
    if (!acc) return;

    const totalAcc = Math.sqrt(
      (acc.x || 0) ** 2 + 
      (acc.y || 0) ** 2 + 
      (acc.z || 0) ** 2
    );

    // 1. Detect Impact
    if (totalAcc > this.CRASH_THRESHOLD) {
      console.log('High impact detected:', totalAcc);
      this.stasisStartTime = Date.now();
    }

    // 2. Detect Stasis after Impact
    if (this.stasisStartTime) {
      if (totalAcc < this.STASIS_THRESHOLD) {
        const timeInStasis = Date.now() - this.stasisStartTime;
        if (timeInStasis > this.STASIS_DURATION) {
          console.log('Crash confirmed: Impact followed by stasis');
          this.triggerEmergency();
          this.stasisStartTime = null; // Reset
        }
      } else {
        // If movement resumes before stasis duration, it might not be a serious crash
        // but we keep the timer running for a bit or reset if movement is high
        if (totalAcc > 15) { // Significant movement
          this.stasisStartTime = null;
        }
      }
    }

    this.lastAcceleration = totalAcc;
  };

  private async triggerEmergency() {
    if (this.isTriggering) return;
    this.isTriggering = true;
    try {
      // 1. Get Location
      const position = await new Promise<GeolocationPosition>((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject, {
          enableHighAccuracy: true,
          timeout: 5000,
          maximumAge: 0
        });
      });

      const { latitude: lat, longitude: lng } = position.coords;

      // 2. Find Nearest Hospital
      const hospital = await getNearestHospital(lat, lng);

      // 3. Notify Emergency Contacts (via Supabase or simulated)
      await this.notifyEmergencyContacts(lat, lng, hospital);

      // 4. Trigger Callback
      this.onCrashDetected({
        timestamp: Date.now(),
        location: { lat, lng },
        hospital
      });

      // 5. Auto-call Hospital
      if (hospital?.phone) {
        window.location.href = `tel:${hospital.phone}`;
      } else {
        window.location.href = `tel:112`; // Universal emergency number fallback
      }

    } catch (error) {
      console.error('Error in emergency trigger:', error);
    }
  }

  private async notifyEmergencyContacts(lat: number, lng: number, hospital: Hospital | null) {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data: patientData } = await supabase
        .from('patient_data')
        .select('emergency_contact_phone, emergency_contact_name')
        .eq('user_id', user.id)
        .single();

      if (patientData?.emergency_contact_phone) {
        console.log(`Notifying ${patientData.emergency_contact_name} at ${patientData.emergency_contact_phone}`);
        // In a real app, we would call a Supabase Edge Function to send an SMS
        // For now, we'll log it and maybe store the alert in a table
        await supabase.from('emergency_alerts').insert({
          user_id: user.id,
          type: 'crash_detected',
          location_lat: lat,
          location_lng: lng,
          hospital_name: hospital?.name,
          contact_notified: patientData.emergency_contact_phone
        });
      }
    } catch (error) {
      console.error('Error notifying emergency contacts:', error);
    }
  }
}

export const crashDetectionService = new CrashDetectionService();
